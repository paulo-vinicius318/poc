package com.poc.restaurantea3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restaurantea3Application {

	public static void main(String[] args) {
		SpringApplication.run(Restaurantea3Application.class, args);
	}

}
